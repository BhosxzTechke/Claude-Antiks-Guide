# Setup checklist

Do these once per project, in order. `/kickoff` and the roadmap cover the Claude parts; the rest are yours.

## 1. Before Claude starts (you)

- [ ] Copy the kit into the project root with hidden files included (`.claude/`, `.github/`, `.gitattributes`, `.gitignore`, `.coderabbit.yaml`).
- [ ] Write `AGENTS.md` in the repo root. Claude reads it and never edits it.
- [ ] Put every doc the project depends on in `docs/` (MVP doc, designs, diagrams) and fill `docs/brief.md`, or let `/kickoff` write the brief.
- [ ] Node **22.x** installed locally (`node -v`), the same major CI and `engines` will use.
- [ ] Decide repo visibility: **private** until every client or unreleased work named in the docs is cleared. Vercel, Railway and similar hosts work with private repos.
- [ ] For web projects: Chrome with the Claude in Chrome extension connected (visual checks don't work in Edge).
- [ ] Optional: copy `.claude/settings.local.example.json` to `.claude/settings.local.json` so screenshot checks stop asking for permission each time.

## 2. `/kickoff`

Run `/kickoff read docs/brief.md`. It writes the workspace CLAUDE.md files (into `.claude/templates/` for workspaces not created yet), CI, review rules, decisions and the roadmap.

## 3. Scaffold each workspace (roadmap, phase 1)

Follow the recipe's "Scaffold" section in `.claude/kit/stacks/`. The order matters:

1. Run the generator (`create-next-app`, `create-expo-app`, `composer create-project`, …) while the workspace folder doesn't exist yet. Generators refuse non-empty folders.
2. Copy `.claude/templates/<workspace>-CLAUDE.md` into the new folder as `CLAUDE.md`.
3. Pin Node: `"engines": { "node": "22.x" }` (exact major, never `>=`) and `@types/node` at `^22` where TypeScript is used.
4. Install Prettier as a devDependency in JS/TS workspaces (the format-on-edit hook does nothing without it).
5. Read every config file the generator wrote and decide each option on purpose. Record what you keep in `docs/decisions.md`.

## 4. Repo, first push, CI

1. Create the repo with the visibility decided above (`gh repo create <name> --private`).
2. First push: `/ship` sees the empty remote and offers one empty `chore: initial commit` on `main`. That's the only commit ever made on `main`; everything else goes through PRs.
3. Watch CI on the first PR: `gh pr checks <n> --watch`. Don't call a PR ready until it's green.

## If something looks wrong

Check the "Known dependency noise" and "Gotchas" sections of the workspace CLAUDE.md, and the Windows notes in the root `CLAUDE.md`, before changing anything.
