# Section references

One image per section, about one screen tall (~1900 × 900). Name them after the section: `hero.png`, `buttons.png`, `pills-chips.png`, `cards.png`, `navbar-footer.png`, …

Claude builds and compares each section against its own image here. Full-page mockups and design-system sheets go one folder up as overviews.
