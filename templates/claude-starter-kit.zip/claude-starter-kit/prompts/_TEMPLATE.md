# NN — Title

**Roadmap item:** NN · **Workspaces:** … · **Status:** draft

## Goal
One or two sentences. What the user can do when this is done.

## Skills used
- …

## Code inspected
- `path/to/file` — what it told you

## Design reference
- Section image(s) in `docs/design/sections/` this task matches (or "no UI")

## Decisions and assumptions
- …

## Files expected to change
- `path` — create / edit, why

## Requirements
1. …

## Not doing
- Tempting extras that belong to a later task

## Security considerations
- Ownership: how every query is scoped to the authenticated user
- Secrets: what stays server-side
- Input / AI output: how it is validated (if relevant)

## Acceptance criteria
- [ ] …

## Checks to run
- Fast (while iterating): `…`
- Slow (in /check before /ship): `…`

## Manual test steps
<!-- KICKOFF: replace "the test device" with the real one, e.g. "the physical Android phone". -->
1. On the test device: …
