# Recipe: Next.js web app (TypeScript, App Router)

Default workspace folder: `web/`

## Scaffold (first roadmap item for this workspace)

Order matters: `create-next-app` refuses a folder that already holds files, including `CLAUDE.md`.

1. Run `npx create-next-app@latest web …` while `web/` does not exist yet (or in a temp folder, then copy in with `cp -rn`, skipping `node_modules`, `.next`, `next-env.d.ts`, and run `npm ci`).
2. Copy `.claude/templates/web-CLAUDE.md` to `web/CLAUDE.md`.
3. `package.json`: `"engines": { "node": "22.x" }` (exact major, not `>=`; Vercel reads it) and `"postinstall": "next typegen"` (generates `LayoutProps`/`PageProps` so `tsc` passes in CI and fresh clones).
4. `npm install -D @types/node@^22 prettier` (generators often install older `@types/node`; the format hook needs Prettier).
5. `next.config.ts`: `agentRules: false` if the project has its own AGENTS.md/CLAUDE.md (stops `next dev` writing `web/AGENTS.md`). Review every other generated option on purpose; the generator may enable things you didn't pick (e.g. `cacheComponents`). Record kept options in `docs/decisions.md`.
6. Run the checks below plus `npm audit --omit=dev`.

## Workspace CLAUDE.md

```markdown
# web/ — Next.js (App Router) + TypeScript

## Run
- `npm run dev` → open the URL it prints (3000, or 3001 if 3000 is taken)
- Node 22.x (matches `engines` and CI)

## Checks
- `npx tsc --noEmit`
- `npm run lint`
- `npm run build` when routes, config, or dependencies change
- `npm audit --omit=dev` when dependencies change (must be 0; see Known dependency noise)

## Rules
- Talk to the project's own API only. No direct database access unless AGENTS.md says this app owns the database.
- Anything prefixed `NEXT_PUBLIC_` ships to the browser. No secrets.
- Server-only code (secrets, admin SDKs) lives in server components, route handlers or server actions, and imports `server-only`.
- Auth tokens in httpOnly cookies, never localStorage.
- Reuse `components/` and the theme. Every page has loading / empty / error states.

## Known dependency noise (do not "fix")
- `npm audit` may report high findings in the dev-only chain `eslint-config-next` → `fast-glob` → `micromatch` → `braces`. If `npm audit --omit=dev` is 0, leave it. Never run `npm audit fix --force`: it downgrades `eslint-config-next` and breaks lint.
- `npm ls` may mark `@tybys/wasm-util`, `@emnapi/*`, `@napi-rs/wasm-runtime`, `@img/sharp-wasm32` as "extraneous". They're optional WebAssembly fallbacks in the lockfile. Leave them; confirm with `npm explain <pkg>`.
```

## Allowed commands
`Bash(npm run lint:*)`, `Bash(npm run build:*)`, `Bash(npm run dev:*)`

## CI job

```yaml
  web:
    needs: changes
    if: needs.changes.outputs.web == 'true'
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: web
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22   # the project's single Node major; match "engines" and local
          cache: npm
          cache-dependency-path: web/package-lock.json
      - run: npm ci
      - run: npx tsc --noEmit
      - run: npm run lint
      - run: npm run build
```

## CodeRabbit path instructions

```yaml
    - path: "web/**"
      instructions: |
        Flag as critical: secrets in client components or NEXT_PUBLIC_ variables; tokens in localStorage; server-only modules imported into client components; data fetched for another user.
        Also check: loading / error boundaries, no unnecessary "use client".
```

## Gitignore
```
web/node_modules/
web/.next/
web/.env*.local
```

## Gotchas
- `NEXT_PUBLIC_*` is inlined at build time; changing it needs a rebuild.
- Server vs client components: a `"use client"` file can't import server-only code.
- Check the installed Next.js major version; App Router APIs changed between versions.
- `tsc` fails on a fresh checkout with `Cannot find name 'LayoutProps'` → the `postinstall: next typegen` script is missing.
- A new `web/AGENTS.md` appears on every `next dev` → `agentRules: false` is missing.
- With Cache Components on, server components can't read the time or request data outside `<Suspense>`.
- These notes were written against Next.js 16.4; re-check on newer versions.
