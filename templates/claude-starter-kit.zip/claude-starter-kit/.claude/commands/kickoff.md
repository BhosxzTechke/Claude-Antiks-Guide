---
description: Turn this starter kit into a project-specific setup from your AGENTS.md and brief. Asks before writing.
argument-hint: <paragraph about the app | "read docs/brief.md" | "add workspace <name> <stack>">
---

Input: $ARGUMENTS

You are setting up this repo's AI workflow. Do not write application code in this command.

**`AGENTS.md` belongs to the user.** They write it; you read it. Never create, rewrite or edit `AGENTS.md`. If something in it conflicts with the brief or the answers, list the conflict in the step 4 summary and let the user fix it.

## 0. Which mode?

- `AGENTS.md` must exist in the repo root. If it doesn't, stop: tell the user to add it first (see `docs/SETUP.md`).
- Run `grep -rl "KICKOFF:" --include=*.md --include=*.yml --include=*.yaml . | grep -v "^./.claude/"` (excluding `.claude/kit/`).
- **Markers found** → full setup (steps 1–7).
- **No markers and input starts with "add workspace"** → add one workspace (step 8 only).
- **No markers otherwise** → tell the user the project is already set up, and offer `/kickoff add workspace …` or `/plan`. Stop.

## 1. Gather context (read, don't assume)

- `AGENTS.md`, the input above, `docs/brief.md`, and every file the user attached or referenced (MVP docs, diagrams, screenshots, design references). If a file the user named doesn't exist, say so; don't guess its contents.
- If the repo already has code: list top-level folders and read each manifest (`package.json`, `composer.json`, `app.json`, `pyproject.toml`, …) to learn the real stack and versions.
- Run `node -v` and note the local Node major.
- Read `.claude/kit/stacks/*.md`. Each is a recipe for one stack.

## 2. Fill the gaps with ONE AskUserQuestion call (max 4 questions)

Only ask what the context doesn't answer. Typical gaps, in priority order:

1. Workspaces / stack (offer the recipes that match, plus "Other")
2. Repo visibility: **Private (Recommended if the docs name clients, unreleased work or anything not cleared)** / Public
3. Code review and CI (GitHub Actions + CodeRabbit / GitHub Actions only / none yet)
4. Where it runs during development (physical phone / emulator / browser; laptop constraints like low RAM)

Node version: use **22.x** unless AGENTS.md or the brief names another. If the local major differs, flag it in the summary; don't ask.

If everything is clear, skip the questions.

## 3. Write `docs/brief.md`

Rewrite it as a clean, complete brief (keep the template's headings). If the user gave a long MVP doc, put it in `docs/` unchanged and link it from the brief — don't duplicate its content.

## 4. Show the plan and ask

Reply with a short summary (bullets, under 15 lines): project name, workspaces + stacks, Node major, repo visibility, roadmap phases, decisions you'll record, files you'll create or rewrite. Flag any conflicts between `AGENTS.md`, the brief and other docs, and say which version you'll follow (AGENTS.md wins).

Then AskUserQuestion, options Yes / No: `Set up the project with this plan?`
On No: ask what to change, update, ask again.

## 5. Generate (on Yes)

For each file below, replace every `KICKOFF:` marker with real content and delete the marker comments.

| File | What to write |
|---|---|
| Workspace CLAUDE.md | One per workspace, from the recipe's "Workspace CLAUDE.md" section, adapted to this project. **Workspace folder doesn't exist yet** → write it to `.claude/templates/<workspace>-CLAUDE.md`; the scaffold roadmap item copies it in after the generator runs (generators refuse non-empty folders). **Folder already has code** → write `<workspace>/CLAUDE.md` directly. |
| `docs/decisions.md` | One line per settled decision, dated today. Always include: Node major, repo visibility, prompt numbering (`NN` = roadmap number, `xNN` = off-roadmap), LF line endings. |
| `docs/roadmap.md` | Phases from the brief, each a list of `- [ ] NN — task` items small enough for one `/plan` (one PR each). Phase 1 always has: one **scaffold** item per new workspace (following the recipe's "Scaffold" section), then one **repo + CI** item (create the repo with the chosen visibility, first push via `/ship`, CI green). |
| `prompts/_TEMPLATE.md` | Adapt "Manual test steps" to the real device; adapt "Security considerations" bullets to the project. |
| `.github/workflows/ci.yml` | One output + filter + job per workspace from each recipe's "CI job". Each filter has two lines: `'<ws>/**'` and `'!<ws>/**/*.md'`. Keep `predicate-quantifier: every` and `pull-requests: read`. Node jobs use the project's Node major. If the user chose no CI, delete the file. |
| `.coderabbit.yaml` | `path_instructions` per workspace from each recipe, made specific to this project. If no CodeRabbit, delete the file. |
| `.claude/settings.json` | Add each recipe's "Allowed commands" to `allow`. Keep all deny rules and the VibeWise entries. |
| `.gitignore` | Add each recipe's ignore lines that aren't already covered by the catch-alls. Keep `.vibe-wise/`. |
| `.github/pull_request_template.md`, `.gitattributes` | Leave as is. |

Project skills: create a skill in `.claude/skills/<name>/SKILL.md` only for a procedure that will repeat across many tasks and isn't already covered by AGENTS.md (e.g. "add an API endpoint the house way"). Zero is a fine number. Max 3.

Stack with no recipe: write `.claude/kit/stacks/<stack>.md` in the same format (including a "Scaffold" section), based on the official docs for the version the user named. Mention it in the step 4 summary.

## 6. Verify

- `grep -rn "KICKOFF:" . --include=*.md --include=*.yml --include=*.yaml --include=*.json | grep -v "^./.claude/"` → must be empty (ignore `.claude/kit/` and this command file).
- `AGENTS.md` is unchanged.
- `.claude/settings.json` parses as JSON; YAML files parse.
- Every workspace has a CLAUDE.md (in its folder or in `.claude/templates/`), a scaffold roadmap item if new, a CI job with the Markdown-excluding filter (if CI), and a CodeRabbit entry (if CodeRabbit).
- Every command in a workspace CLAUDE.md "Checks" is allowed or asked in settings.

## 7. Report

Short bullets under **What I set up**, **Next step** (usually `/plan` for roadmap item 01), **Needs your attention** (secrets to create, accounts to sign up for, Node version mismatch, anything you assumed). Point the user to `docs/SETUP.md` for the steps only they can do. Remind them to run `/vibe-wise:learn` once if they want learning mode. Do not commit. Suggest reviewing the diff, then `/ship` it as `chore: project setup` (on an empty remote, `/ship` offers the first empty commit on `main` first).

## 8. Add workspace (mode from step 0)

Read the matching recipe (write one if missing, as in step 5), then: write the workspace CLAUDE.md (to `.claude/templates/` if the folder doesn't exist yet), add a scaffold item to `docs/roadmap.md`, the CI job, CodeRabbit entry, settings commands and gitignore lines. List the `AGENTS.md` sections the user should update (structure, architecture, stack); don't edit it. Show the list of changes and ask Yes / No before writing.
