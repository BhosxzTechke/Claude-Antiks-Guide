---
description: Branch, commit, push and open a PR for the current task.
argument-hint: [optional prompt file, e.g. prompts/05-settings-page.md]
---

Prompt file: $ARGUMENTS (if empty, use the most recent file in `prompts/` that matches the changes).

1. If the last `/check` in this session was not all green, run the `/check` steps first. Stop if anything fails.
2. **Empty remote (first ship only).** Run `git ls-remote --heads origin`. If it prints nothing, the remote has no `main` for a PR to target. Ask with AskUserQuestion (Yes / No): `The remote is empty. Push one empty commit to main so PRs have a base?` On Yes, run exactly:
   - `git checkout -b main` (only if no local `main` exists; otherwise `git checkout main`). Unstaged work carries over untouched.
   - `git diff --cached --quiet` must succeed (nothing staged). If it fails, stop and tell the user: a staged file would land on `main`.
   - `git commit --allow-empty -m "chore: initial commit"`
   - `git push -u origin main`
   This is the only commit ever allowed on `main`. It contains no files. Then continue on a branch.
3. If on `main`, create a branch named after the prompt: `feat/NN-short-name` (`fix/…` for bug fixes, `chore/…` for setup). Never commit to `main`.
4. Show `git status` and stage only files that belong to this task. Never stage `.env` files, credentials, build output, or `.vibe-wise/`.
5. If `docs/roadmap.md` has a matching item, tick it `- [x]`.
6. Commit with a conventional message, e.g. `feat(web): settings page`, and a body line `Prompt: prompts/NN-name.md`.
7. Push the branch (`git push -u origin <branch>`) and open a PR with `gh pr create`. Title = commit subject. Body (follows `.github/pull_request_template.md`):
   - Prompt: link to the prompt file
   - What I did (short bullets)
   - Test (numbered manual steps from the prompt)
   - Checks (the `/check` table)
   - Needs your attention (or "None")
8. **Watch CI before calling it ready:** `gh pr checks <number> --watch`. Report what actually ran, passed, failed or skipped. If anything you wrote in the PR body (e.g. "build will skip") doesn't match, edit the PR body to match reality.
9. Do not merge. Reply with one line: the PR link and the real CI result. Then suggest `/clear` before the next task.
