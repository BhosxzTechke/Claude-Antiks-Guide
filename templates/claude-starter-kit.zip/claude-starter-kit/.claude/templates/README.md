# Workspace CLAUDE.md templates

`/kickoff` writes `<workspace>-CLAUDE.md` here for every workspace that doesn't exist yet.

Project generators (`create-next-app`, `create-expo-app`, `composer create-project`, …) refuse to run in a folder that already has files, so the workspace's CLAUDE.md waits here. The workspace's scaffold roadmap item runs the generator first, then copies the file in as `<workspace>/CLAUDE.md`.
