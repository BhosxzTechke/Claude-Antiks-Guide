# Claude Starter Kit

A drop-in folder that sets up Claude Code for any new project: it plans first, teaches you as it builds (VibeWise learning mode), runs real checks, and never merges. Lessons from earlier projects are built in, so the same setup problems don't come back.

## Use it on a new project

1. Copy **everything inside this folder** into your new project root. Turn on hidden items in File Explorer first: `.claude/`, `.github/`, `.gitattributes`, `.gitignore` and `.coderabbit.yaml` are hidden.
2. **Write your own `AGENTS.md`** in the project root. The kit doesn't include one; Claude reads yours and never edits it. `CLAUDE.md` imports it automatically.
3. Work through section 1 of `docs/SETUP.md` (Node 22, repo visibility, Chrome for web projects).
4. Open Claude Code in that folder. Trust the folder when asked; Claude Code then offers to install **VibeWise** (declared in `.claude/settings.json`).
5. Run:

   ```
   /kickoff <one paragraph about your app, or "read docs/brief.md">
   ```

6. Claude asks a few multiple-choice questions, shows a summary, and asks before writing.
7. On "Yes" it fills in the kit for your project: workspace CLAUDE.md files, `docs/`, CI, CodeRabbit rules, permissions and the roadmap. It never touches `AGENTS.md`.
8. Run `/plan`. Phase 1 of the roadmap scaffolds each workspace and sets up the repo.

## Daily loop

| Command | What happens |
|---|---|
| `/plan <task>` | Writes `prompts/NN-name.md`, asks "Is this good to execute?". No code until Yes. |
| `/plan` (no task) | Picks the next unchecked item in `docs/roadmap.md` |
| `/check` | Runs the real checks for changed workspaces, reports a table. Doesn't fix unless you ask. |
| `/ship` | Branch, commit, push, open the PR, watch CI, tick the roadmap item. Never merges. On an empty remote, offers the one empty commit on `main` first. |

Prompt numbers: roadmap tasks use the roadmap number (`05-…`); anything else uses `x01`, `x02`, ….

Claude **never** merges, force-pushes, pushes work to `main`, reads `.env` files, or runs destructive DB commands. Those are blocked in `.claude/settings.json`, not just written in instructions.

## VibeWise

[VibeWise](https://github.com/nykooi1/vibe-wise) (community plugin, not Anthropic-reviewed) is a learning mode: Claude asks for your approach first, explains concepts, and writes only the code you agree on.

- If the install prompt doesn't appear (e.g. in the VS Code extension), install it once per computer. Windows steps are in `docs/vibewise-install.md`:

  ```
  claude plugin marketplace add nykooi1/vibe-wise
  claude plugin install vibe-wise@vibe-wise
  ```

- Notes are saved in `.vibe-wise/` (gitignored). Pause it by telling Claude "pause learning mode".

## What's inside

```
CLAUDE.md                     Claude Code entry point; imports your AGENTS.md
.claude/
  settings.json               VibeWise + permissions (allow / deny) + format hook
  settings.local.example.json Optional: lets Claude take screenshots in Chrome without asking
  commands/                   /kickoff /plan /check /ship
  hooks/format.mjs            Auto-formats edited files (never blocks)
  kit/stacks/                 Recipes per stack: scaffold, checks, CI job, review rules, gotchas
  templates/                  Workspace CLAUDE.md files waiting for their scaffold (kickoff fills)
  skills/                     Project skills kickoff creates (only if useful)
docs/
  SETUP.md                    One-time setup checklist, in order
  brief.md                    What you're building (input for /kickoff)
  decisions.md                Settled decisions, newest first
  roadmap.md                  Checkbox list /plan and /ship work through
  vibewise-install.md         VibeWise install guide (Windows)
prompts/_TEMPLATE.md          Implementation prompt template
.github/                      CI workflow + PR template
.gitattributes                LF line endings everywhere
.gitignore                    Secrets, dependencies, build output, logs
.coderabbit.yaml              Review rules
examples/                     A filled brief (Don't Forget) for reference
```

Recipes: `nextjs-web`, `laravel-api`, `expo-mobile`, `trigger-jobs`. For another stack, `/kickoff` writes a recipe from the official docs and asks you to approve it first.

## Lessons built in

| Problem seen before | Prevented by |
|---|---|
| CI path filter fails on a private repo | `pull-requests: read` in `ci.yml` |
| CI builds a workspace before the app exists | Filters ignore Markdown (`'!<ws>/**/*.md'`) |
| CI on Node 20, local on Node 22 | One Node major: CI, `engines` (`22.x`), local |
| `@types/node` behind the runtime | Scaffold step: `@types/node@^22` |
| Every file shows as changed on Windows | `.gitattributes` (LF) |
| Junk files committed | `.gitignore` catch-alls |
| Generator refuses a folder holding `CLAUDE.md` | Workspace CLAUDE.md waits in `.claude/templates/` until scaffolded |
| Format hook does nothing | Prettier installed in every scaffold |
| Generator enabled options nobody chose | Scaffold step: review every config option |
| No `main` for the first PR | `/ship` empty-remote step |
| Public repo named clients | Visibility asked in `/kickoff`; private by default |
| Two prompts numbered `01` | One numbering rule in `/plan` |
| PR body claimed something CI didn't do | `/ship` watches `gh pr checks` and corrects the body |
| Screenshots failed in Edge | Chrome rule in `CLAUDE.md` and `SETUP.md` |
| Missing doc reported mid-task | `CLAUDE.md`: check required files before starting |
| Next.js: `tsc` can't find `LayoutProps` in CI | `nextjs-web` recipe: `postinstall: next typegen` |
| Next.js: `next dev` writes its own `AGENTS.md` | `nextjs-web` recipe: `agentRules: false` |
| `npm audit fix --force` broke lint | `nextjs-web` recipe: "Known dependency noise" |
| Windows: port taken / server won't stop | Windows notes in `CLAUDE.md` |

## Adding a stack later

Run `/kickoff add workspace <name> <stack>` after the project is set up. It writes the workspace CLAUDE.md, CI job and roadmap scaffold item, and tells you which parts of your `AGENTS.md` to update.

## Keeping the kit up to date

Keep a clean copy of this folder (or a Git repo of it). When a project teaches you something new, add it to the matching recipe or command and to the table above.
