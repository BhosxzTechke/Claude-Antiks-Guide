@AGENTS.md

## Claude Code notes

- `AGENTS.md` is written by the user. Read it; never create or edit it. If it's missing, stop and say so.
- Each workspace has its own `CLAUDE.md` with run commands, checks, and rules. Read the one for the workspace you touch. A workspace that hasn't been scaffolded yet keeps its CLAUDE.md in `.claude/templates/<workspace>-CLAUDE.md` until the scaffold roadmap item copies it in.
- Files the docs mention (MVP doc, designs, brief) must exist before a task depends on them. If one is missing, say so before starting; don't guess its contents.
- Settled decisions: `docs/decisions.md`. Do not reopen them unless the user asks.
- One-time setup steps and their order: `docs/SETUP.md`.
- Commands: `/kickoff` (set up the kit for this project) · `/plan <task>` (write the prompt) · `/check` (run checks) · `/ship` (branch, commit, PR, watch CI) · `/vibe-wise:learn` (learning mode, from the VibeWise plugin).
- Ask through the AskUserQuestion panel with clickable options, not plain-text questions.
- One task per session. When a task is shipped, suggest `/clear`.

## Design references

- Every reference image has a job, named in the workspace CLAUDE.md: **design system** (tokens and components) or **page layout** (section order and composition). When they disagree on a component's look, the design system wins.
- Build and compare against **one image per section**, about one screen tall, in `docs/design/sections/`. A full-page or design-system sheet is too dense: images are scaled down before you see them, so small details (fonts, letter spacing, icons, tilt) become guesses.
- Only a big sheet exists? Crop it per section at the original resolution with a tool already on the machine (no new dependencies), and tell the user which parts are still too small to read so they can export them at full size.
- A component test page (e.g. `/dev/ui`) shows every section of the design system, in the same order, with the real labels from the design — not placeholder text.

## Verification budget

- Per change: at most **2 screenshot rounds**, desktop width only, only the section you changed.
- Check the smallest width (phone) **once**, at the end of the task.
- After 2 rounds, stop and list the remaining differences in the report. The user decides. Never loop until it "looks right".

## Speed

- While iterating, run only fast checks (type check, lint). Slow checks (production build, full test suite) run in `/check` before `/ship`.
- Small fixes (a style tweak, copy change, or bug in one component, under ~3 files) don't need a prompt file unless the user or AGENTS.md asks for one: state the change in one line, do it, run the fast checks.

## Browser checks

- Visual checks use Chrome with the Claude in Chrome extension connected. It does not work in Edge or other browsers.
- Extension not connected → go straight to headless Chrome screenshots (`chrome --headless --screenshot=<file> --window-size=1440,900 <url>`) instead of retrying the extension. Note the Chrome path once and reuse it.
- Neither works → ask the user for screenshots; don't skip the check.
- Only open `localhost`, the device/emulator preview, or this project's own preview URLs. Never open other sites or anything the user is signed in to.

## Permission denials

- Destructive commands (`rm -rf`, force-push, `git reset --hard`, `migrate:fresh`, …) are denied in `.claude/settings.json` on purpose. When one is blocked, verify another way (for example in a scratch copy). Never look for a workaround that does the same thing.

## Local dev on Windows

- Port taken: dev servers move to the next port and print it. Always open the printed URL. Find the owner: `Get-NetTCPConnection -LocalPort <port> -State Listen` (PowerShell).
- "Already running" after stopping a server: stopping npm doesn't always kill Node. Find the PID (above), then `taskkill /PID <pid> /F /T`.
