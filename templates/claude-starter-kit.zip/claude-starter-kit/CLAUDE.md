@AGENTS.md

## Claude Code notes

- `AGENTS.md` is written by the user. Read it; never create or edit it. If it's missing, stop and say so.
- Each workspace has its own `CLAUDE.md` with run commands, checks, and rules. Read the one for the workspace you touch. A workspace that hasn't been scaffolded yet keeps its CLAUDE.md in `.claude/templates/<workspace>-CLAUDE.md` until the scaffold roadmap item copies it in.
- Files the docs mention (MVP doc, designs, brief) must exist before a task depends on them. If one is missing, say so before starting; don't guess its contents.
- Settled decisions: `docs/decisions.md`. Do not reopen them unless the user asks.
- One-time setup steps and their order: `docs/SETUP.md`.
- Commands: `/kickoff` (set up the kit for this project) · `/plan <task>` (write the prompt) · `/check` (run checks) · `/ship` (branch, commit, PR, watch CI) · `/vibe-wise:learn` (learning mode, from the VibeWise plugin).
- Ask through the AskUserQuestion panel with clickable options, not plain-text questions.
- One task per session. When a task is shipped, suggest `/clear`.

## Browser checks

- Visual checks use Chrome with the Claude in Chrome extension connected. It does not work in Edge or other browsers. If it isn't connected, ask the user to check by hand and share screenshots; don't skip the check.
- Only open `localhost`, the device/emulator preview, or this project's own preview URLs. Never open other sites or anything the user is signed in to.

## Permission denials

- Destructive commands (`rm -rf`, force-push, `git reset --hard`, `migrate:fresh`, …) are denied in `.claude/settings.json` on purpose. When one is blocked, verify another way (for example in a scratch copy). Never look for a workaround that does the same thing.

## Local dev on Windows

- Port taken: dev servers move to the next port and print it. Always open the printed URL. Find the owner: `Get-NetTCPConnection -LocalPort <port> -State Listen` (PowerShell).
- "Already running" after stopping a server: stopping npm doesn't always kill Node. Find the PID (above), then `taskkill /PID <pid> /F /T`.
