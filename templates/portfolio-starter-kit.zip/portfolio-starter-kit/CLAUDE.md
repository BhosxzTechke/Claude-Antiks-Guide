@AGENTS.md

## Claude Code notes

- Required files: `AGENTS.md`, `docs/mvp.md`, `docs/design/home.png`. If one is missing, say so before starting any task. Don't guess its contents.
- The site lives in `web/`. Read `web/CLAUDE.md` before touching it. Until roadmap item 01 is done, `web/` doesn't exist; its CLAUDE.md waits in `.claude/templates/web-CLAUDE.md`.
- Setup steps and their order: `docs/SETUP.md`.
- Settled decisions: `docs/decisions.md`. Do not reopen them unless the user asks.
- Commands: `/plan <task>` (write the prompt) · `/check` (run checks) · `/ship` (branch, commit, PR) · `/vibe-wise:learn` (learning mode, from the VibeWise plugin).
- Skills: `build-section` (any home page section) · `add-portfolio-project` (add or edit a case study).
- Ask through the AskUserQuestion panel with clickable options, not plain-text questions.
- One task per session. When a task is shipped, suggest `/clear`.

## Browser checks

- Visual checks use Chrome with the Claude in Chrome extension connected. It does not work in Edge or other browsers. If it isn't connected, ask the user to check by hand and share screenshots; don't skip the check.
- Only open `localhost` or this project's Vercel preview URLs. Never open other sites or anything the user is signed in to.

## Permission denials

- Destructive commands (`rm -rf`, force-push, `git reset --hard`, …) are denied in `.claude/settings.json` on purpose. When one is blocked, verify another way (for example in a scratch copy). Never look for a workaround that does the same thing.
