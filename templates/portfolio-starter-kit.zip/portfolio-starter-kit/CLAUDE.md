@AGENTS.md

## Claude Code notes

- The site lives in `web/`. Read `web/CLAUDE.md` before touching it.
- Approved design: `docs/design/home.png`. Look at it before any UI work.
- Settled decisions: `docs/decisions.md`. Do not reopen them unless the user asks.
- Commands: `/plan <task>` (write the prompt) · `/check` (run checks) · `/ship` (branch, commit, PR) · `/vibe-wise:learn` (learning mode, from the VibeWise plugin).
- Skills: `build-section` (any home page section) · `add-portfolio-project` (add or edit a case study).
- Ask through the AskUserQuestion panel with clickable options, not plain-text questions.
- One task per session. When a task is shipped, suggest `/clear`.
