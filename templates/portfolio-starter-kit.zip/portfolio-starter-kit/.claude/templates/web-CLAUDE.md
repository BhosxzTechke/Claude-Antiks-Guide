# web/ — Next.js (App Router) + TypeScript + Tailwind + Motion

<!-- Copied to web/CLAUDE.md in roadmap item 01, AFTER create-next-app has generated web/. -->

## Run
- `npm run dev` → open the URL it prints (3000, or 3001 if 3000 is taken)
- Node **22.x** only (matches `engines` and CI)

## Checks
- `npx tsc --noEmit`
- `npm run lint`
- `npm run build` (always: it catches static-generation, metadata and image errors)
- `npm audit --omit=dev` when dependencies change (must be 0; see "Known dependency noise")

## Required package.json setup
- `"engines": { "node": "22.x" }` (exact major, not `>=22`; Vercel reads it)
- `"postinstall": "next typegen"` so `LayoutProps`/`PageProps` exist in CI and fresh clones before any build
- `@types/node` at `^22`
- `prettier` as a devDependency (the format-on-edit hook does nothing without it)

## Required next.config.ts setup
- `agentRules: false` — this repo has its own AGENTS.md/CLAUDE.md; stop `next dev` generating `web/AGENTS.md`
- Every other option is a deliberate decision. The generator may enable options you didn't pick (e.g. `cacheComponents`, `partialPrefetching`). With Cache Components on, server components can't read the time or request data outside `<Suspense>`. Record each kept option in `docs/decisions.md`.

## Design
- Approved design: `../docs/design/home.png`. Match layout, spacing, type and color.
- Tokens (colors, fonts, radii, pastel tints) live in `src/app/globals.css` as CSS variables mapped into the Tailwind theme. Never hardcode a hex value in a component.
- Fonts via `next/font`: Instrument Serif (headlines, italic accents) and Inter Tight (body). A monospace for eyebrow labels.

## Rules
- Content lives in `src/data/*.ts`. Components never hardcode copy.
- Server components by default. `"use client"` only on small leaf components that need motion, drag, physics, scroll or state.
- Matter.js and Embla load with `next/dynamic` and `ssr: false`, with a static fallback rendered first.
- Every animation respects `prefers-reduced-motion`: Motion's `useReducedMotion`, Lenis off, pills shown as a static row, marquee paused.
- Images via `next/image` with width/height, or `fill` + `sizes`. Screenshots in `public/projects/<slug>/`, WebP, under ~300 KB.
- Every page exports `metadata`. Case studies use `generateStaticParams` + `generateMetadata`.
- Check every section at 375px, 768px and 1440px.
- No secrets. Contact is a `mailto:` link.

## Known dependency noise (do not "fix")
- `npm audit` may report high-severity findings in the dev-only chain `eslint-config-next` → `fast-glob` → `micromatch` → `braces`. If `npm audit --omit=dev` is 0, leave it. **Never run `npm audit fix --force`**: it downgrades `eslint-config-next` and breaks lint.
- `npm ls` may mark `@tybys/wasm-util`, `@emnapi/*`, `@napi-rs/wasm-runtime`, `@img/sharp-wasm32` as "extraneous". They are optional WebAssembly fallbacks in the lockfile. Leave them; confirm with `npm explain <pkg>`.

## Gotchas
- Sticky stacking: each stacked section needs its own background and a higher z-index than the one before.
- `position: sticky` stops working if an ancestor has `overflow: hidden` or `auto`. Use `overflow: clip` when you need clipping.
- Lenis scrolls the window, so sticky and Motion `useScroll` still work. Start it once in a client provider; destroy it on unmount.
- Matter.js: create the engine in `useEffect` and clean up (`Runner.stop`, `Engine.clear`, listeners) or hot reload stacks engines. Move pills with `transform` in `requestAnimationFrame`, never React state per frame. Rebuild walls on resize.
- Embla loop needs enough slides to fill the track; duplicate short lists.
- Motion is the `motion` package, imported from `motion/react` (not `framer-motion`). Check the installed version.
- The live clock causes hydration mismatches: render the time only after mount.

## Windows
- Port taken: `next dev` moves to 3001 and prints it. Always open the printed URL. Find the owner: `Get-NetTCPConnection -LocalPort 3000 -State Listen` (PowerShell).
- "Another next dev server is already running": stopping npm didn't kill Node. Find the PID (above), then `taskkill /PID <pid> /F /T`.
