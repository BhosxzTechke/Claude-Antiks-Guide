---
description: Write an implementation prompt in prompts/ and ask for approval. No code until Yes.
argument-hint: [what to build, e.g. "services section"] — empty = next roadmap item
---

Task: $ARGUMENTS

Follow the workflow in AGENTS.md. Do not write or edit application code until the user says Yes.

1. **Pick the task.** If the task above is empty, take the first unchecked `- [ ]` item in `docs/roadmap.md` and say which one you picked.
2. **Read** AGENTS.md (already loaded), `docs/decisions.md`, and the `CLAUDE.md` of every workspace this task touches. List `.claude/skills/` and read any skill that matches.
3. **Inspect** the code and config the task depends on. Note exactly which files you read.
4. **Ask** ONE focused question with AskUserQuestion only if the task is genuinely ambiguous.
5. **Number it** (one rule, so two files never share a number):
   - Roadmap task → the roadmap number: `prompts/05-selected-work-cards.md`.
   - Task not on the roadmap → `x` + a running count: highest `xNN` in `prompts/` + 1, starting at `x01`: `prompts/x01-fix-navbar-focus.md`.
   - A file with that number already exists → you are redoing that task: update the existing file, never create a second one.
6. **Fill** it from `prompts/_TEMPLATE.md`. Every section is required. Keep scope to exactly this task; tempting extras go under "Not doing". If it needs more than ~15 files, note a suggested split under "Decisions and assumptions".
7. **Ask** with AskUserQuestion:
   - Question: `I prepared the implementation prompt at prompts/NN-name.md. Is this good to execute?`
   - Options: **Yes** · **No**

On **Yes**: implement strictly to the prompt. If VibeWise learning mode is on, follow its checkpoints during implementation, inside the prompt's scope (see AGENTS.md). If the prompt turns out wrong or incomplete, or a fix fails in a way the prompt didn't expect, stop, update the prompt file first, and ask again. The prompt is the record of what happened. When done, run the `/check` steps and report (What I did / Test / Needs your attention).

On **No**: ask what to change, update the prompt, and ask again.
