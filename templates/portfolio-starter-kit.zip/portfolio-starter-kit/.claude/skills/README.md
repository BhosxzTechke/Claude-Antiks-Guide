# Project skills

- `build-section/` — building or changing any home page section or effect
- `add-portfolio-project/` — adding, editing or removing a project / case study

Add a skill only for a procedure that repeats across many tasks and isn't already covered by `AGENTS.md` or `web/CLAUDE.md`. When the same correction comes up in two different tasks, that's a sign it belongs in a skill.
