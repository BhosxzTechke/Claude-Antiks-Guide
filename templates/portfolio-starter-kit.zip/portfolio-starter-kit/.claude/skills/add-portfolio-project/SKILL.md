---
name: add-portfolio-project
description: Use when adding, editing or removing a project or case study on the portfolio. Covers the data entry, screenshots, case study page, metadata and checks.
---

# Add a portfolio project

1. Collect what's missing in ONE AskUserQuestion call: name, year, role, one-line outcome headline, 2–4 metrics, tech, featured or not, live URL, and whether client work may be shown publicly.
2. Add the entry to `web/src/data/projects.ts`, following the existing type. `slug` is unique kebab-case. Featured projects max 4: adding a 5th → ask which one moves to Playground.
3. Screenshots go in `web/public/projects/<slug>/` as `cover.webp`, `01.webp`, … (max 2400px wide, under ~300 KB). No screenshots provided → stop and ask. Never use AI mockup screens as real work.
4. Metrics: only numbers the user gave. Never invent percentages or results.
5. Case study: fill the entry's `caseStudy` fields (problem, role, process, result) in the same shape as the newest existing one; `/work/[slug]` is generated from the data.
6. Card tint: pick a pastel token not used by the card above or below it.
7. Run `npx tsc --noEmit`, `npm run lint`, `npm run build` from `web/`. Open `/` and `/work/<slug>` at 375px and 1440px and compare with the other cards.
8. Report: What I did / Test / Needs your attention.
