---
name: build-section
description: Use when building or changing any home page section (Navbar, Hero, Selected Work, Services, Toolbox, Footer) or adding an effect to one. Covers design matching, data, static-first build, effects, reduced motion and the screenshot check.
---

# Build a section

1. **Look at the design.** Open `docs/design/home.png` and describe the section to yourself: layout, sizes, spacing, type, colors, every piece of text.
2. **Content first.** Every string, link, number and image path goes in `web/src/data/`. If the data file lacks a field, add it to the type. Never invent metrics or copy that isn't in the design or the brief; ask.
3. **Tokens.** Use the CSS variables and Tailwind theme in `globals.css`. Need a new color or radius? Add a token, never a raw hex in a component.
4. **Static first.** Build the section as a server component in `web/src/components/<section>/` with no animation. It must look right at 375px, 768px and 1440px before any effect.
5. **Then the effect** (only if the roadmap item asks for it): a small `"use client"` leaf component. Heavy libraries (Matter.js, Embla) via `next/dynamic` with `ssr: false`, rendering the static version as fallback.
6. **Reduced motion.** With `prefers-reduced-motion: reduce`, the section shows all content with no motion. Test it in DevTools → Rendering → Emulate CSS media feature.
7. **Accessibility.** Real headings in order, buttons are `<button>` or `<a>`, visible focus ring, alt text on images, draggable things also work without dragging.
8. **Checks.** From `web/`: `npx tsc --noEmit`, `npm run lint`, `npm run build`.
9. **Compare.** Screenshot the section at 1440px and 375px, put it next to the design, list differences, fix, repeat until none matter.
10. **Report:** What I did / Test / Needs your attention.
