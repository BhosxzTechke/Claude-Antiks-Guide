# Portfolio Starter Kit — Dan Antiquina v2

Claude Code setup for the portfolio redesign. Claude plans first, matches the approved design, runs real checks, and never merges.

## Use it

1. Unzip and copy **everything inside this folder** into your new project root. Turn on hidden items in File Explorer first: `.claude/`, `.github/`, `.gitattributes`, `.gitignore` and `.coderabbit.yaml` are hidden.
2. Add the files only you provide:
   - `AGENTS.md` (repo root) — your project rules
   - `docs/mvp.md` — the approved MVP documentation, exported as Markdown
3. Work through **Before Claude starts** in `docs/SETUP.md` (Node 22, Chrome, repo visibility).
4. Open Claude Code there, trust the folder, install VibeWise if prompted (`docs/vibewise-install.md`).
5. Run `/plan`. It picks roadmap item **01** (scaffold `web/`). Approve, let Claude build, `/check`, `/ship`. Repeat.

## Required files

Claude stops and tells you if one is missing.

| File | Who provides it |
|---|---|
| `AGENTS.md` | You |
| `docs/mvp.md` | You (export from the MVP doc) |
| `docs/design/home.png` | Included |
| `web/CLAUDE.md` | Claude, in roadmap item 01, from `.claude/templates/web-CLAUDE.md` |

## Daily loop

| Command | What happens |
|---|---|
| `/plan <task>` | Writes `prompts/NN-name.md`, asks "Is this good to execute?". No code until Yes. |
| `/plan` (no task) | Picks the next unchecked item in `docs/roadmap.md` |
| `/check` | Runs tsc, lint and build in `web/`, reports a table. |
| `/ship` | Branch, commit, push, open the PR, watch CI, tick the roadmap item. Never merges. On an empty remote, offers the one empty commit on `main` first. |

## What's inside

```
CLAUDE.md                     Claude Code entry point; imports your AGENTS.md
.claude/
  settings.json               VibeWise + permissions + format hook
  settings.local.example.json Optional: lets Claude take screenshots in Chrome without asking
  commands/                   /plan /check /ship
  hooks/format.mjs            Auto-formats edited files with Prettier
  skills/                     build-section, add-portfolio-project
  templates/web-CLAUDE.md     Becomes web/CLAUDE.md after scaffolding
docs/
  SETUP.md                    One-time setup checklist, in order
  brief.md                    Content: projects, services, toolbox
  decisions.md                Settled decisions
  roadmap.md                  18 items in 5 phases
  design/home.png             Approved home page design
  vibewise-install.md         VibeWise install guide (Windows)
prompts/_TEMPLATE.md          Implementation prompt template
.github/                      CI (Node 22; tsc, lint, build on web/) + PR template
.gitattributes                LF line endings everywhere
.coderabbit.yaml              Review rules
```

## Lessons built in

| Problem seen before | Prevented by |
|---|---|
| CI filter fails on a private repo | `pull-requests: read` in `ci.yml` |
| CI builds before the app exists | Path filter ignores Markdown |
| CI Node 20 vs local Node 22 | Node 22.x in CI, `engines`, SETUP.md |
| Every file shows as changed on Windows | `.gitattributes` (LF) |
| `create-next-app` refuses non-empty `web/` | `web/CLAUDE.md` ships as a template, copied after scaffolding |
| `tsc` can't find `LayoutProps` in CI | `postinstall: next typegen` |
| `next dev` writes its own `AGENTS.md` | `agentRules: false` |
| Format hook does nothing | Prettier installed in item 01 |
| No `main` for the first PR | `/ship` empty-remote step |
| Public repo named clients | Private by default (SETUP.md, decisions) |
| `npm audit fix --force` breaks lint | "Known dependency noise" in web CLAUDE.md |
| Two prompts numbered `01` | One numbering rule in `/plan` |
| PR body claimed CI would skip | `/ship` watches `gh pr checks` |
| Screenshots failed in Edge | Chrome rule in CLAUDE.md + SETUP.md |
