# Portfolio Starter Kit — Dan Antiquina v2

Claude Code setup for the portfolio redesign, already filled in. Claude plans first, matches the approved design, runs real checks, and never merges.

## Use it

1. Unzip and copy **everything inside this folder** (including hidden `.claude/`, `.github/`, `.coderabbit.yaml`, `.gitignore`) into your new project root.
2. Open Claude Code there and trust the folder. Install VibeWise if prompted (see `docs/vibewise-install.md`).
3. Run `/plan`. It picks roadmap item **01** (create the Next.js app in `web/`).
4. Approve the prompt, let Claude build, run `/check`, then `/ship`.
5. Repeat `/plan` for each roadmap item.

No `/kickoff` needed: AGENTS.md, docs and CI are already written for this project. Answer the open questions in `docs/brief.md` first (repo, domain, client permission).

## Daily loop

| Command | What happens |
|---|---|
| `/plan <task>` | Writes `prompts/NN-name.md`, asks "Is this good to execute?". No code until Yes. |
| `/plan` (no task) | Picks the next unchecked item in `docs/roadmap.md` |
| `/check` | Runs tsc, lint and build in `web/`, reports a table. |
| `/ship` | Branch, commit, push, open the PR, tick the roadmap item. Never merges. |

## What's inside

```
AGENTS.md                  Project rules: scope, design tokens, structure, stack, product rules
CLAUDE.md                  Claude Code entry point; imports AGENTS.md
web/CLAUDE.md              Run commands, checks, rules and gotchas for the Next.js site
.claude/
  settings.json            VibeWise + permissions + format hook
  commands/                /plan /check /ship
  hooks/format.mjs         Auto-formats edited files with Prettier
  skills/
    build-section/         How to build any home page section or effect
    add-portfolio-project/ How to add a project / case study
docs/
  brief.md                 Content: projects, services, toolbox, open questions
  decisions.md             Settled decisions
  roadmap.md               18 items in 5 phases, with a gate before effects
  design/home.png          Approved home page design
  vibewise-install.md      VibeWise install guide (Windows)
prompts/_TEMPLATE.md       Implementation prompt template
.github/                   CI (tsc, lint, build on web/) + PR template
.coderabbit.yaml           Review rules for the portfolio
```

Build plan with diagrams: https://claude.ai/code/artifact/863f1133-008e-47c9-a8e8-b73e1bbfc63e
