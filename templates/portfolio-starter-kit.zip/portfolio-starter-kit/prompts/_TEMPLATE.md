# NN — Title

**Roadmap item:** NN · **Workspaces:** web · **Status:** draft

## Goal
One or two sentences. What a visitor sees or can do when this is done.

## Skills used
- …

## Code inspected
- `path/to/file` — what it told you

## Design reference
- Which part of `docs/design/home.png` (or "no design — asked the user")

## Decisions and assumptions
- …

## Files expected to change
- `path` — create / edit, why

## Requirements
1. …

## Not doing
- Tempting extras that belong to a later task

## Content and motion
- Content: which `src/data/` fields are used or added; nothing invented
- Reduced motion: what the section shows with `prefers-reduced-motion: reduce`
- Performance: client JS added, images and their sizes

## Acceptance criteria
- [ ] Matches the design at 1440px
- [ ] Works at 375px and 768px
- [ ] …

## Checks to run
- `npx tsc --noEmit`
- `npm run lint`
- `npm run build`

## Manual test steps
1. In Chrome at 1440px: …
2. DevTools device toolbar at 375px: …
3. DevTools → Rendering → emulate `prefers-reduced-motion: reduce`: …
