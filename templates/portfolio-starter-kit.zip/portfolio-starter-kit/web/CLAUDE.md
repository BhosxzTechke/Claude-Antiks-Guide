# web/ — Next.js (App Router) + TypeScript + Tailwind + Motion

## Run
- `npm run dev` → http://localhost:3000

## Checks
- `npx tsc --noEmit`
- `npm run lint`
- `npm run build` (always: it catches static-generation, metadata and image errors)

## Design
- Approved design: `../docs/design/home.png`. Match layout, spacing, type and color.
- Tokens (colors, fonts, radii, pastel tints) live in `src/app/globals.css` as CSS variables mapped into the Tailwind theme. Never hardcode a hex value in a component.
- Fonts via `next/font`: Instrument Serif (headlines, italic accents) and Inter Tight (body). A monospace for eyebrow labels.

## Rules
- Content lives in `src/data/*.ts`. Components never hardcode copy.
- Server components by default. `"use client"` only on small leaf components that need motion, drag, physics, scroll or state.
- Matter.js and Embla load with `next/dynamic` and `ssr: false`, with a static fallback rendered first.
- Every animation respects `prefers-reduced-motion`: Motion's `useReducedMotion`, Lenis off, pills shown as a static row, marquee paused.
- Images via `next/image` with width/height, or `fill` + `sizes`. Screenshots in `public/projects/<slug>/`, WebP, under ~300 KB.
- Every page exports `metadata`. Case studies use `generateStaticParams` + `generateMetadata`.
- Check every section at 375px, 768px and 1440px.
- No secrets. Contact is a `mailto:` link.

## Gotchas
- Sticky stacking: each stacked section needs its own background and a higher z-index than the one before.
- `position: sticky` stops working if an ancestor has `overflow: hidden` or `auto`. Use `overflow: clip` when you need clipping.
- Lenis scrolls the window, so sticky and Motion `useScroll` still work. Start it once in a client provider; destroy it on unmount.
- Matter.js: create the engine in `useEffect` and clean up (`Runner.stop`, `Engine.clear`, listeners) or hot reload stacks engines. Move pills with `transform` in `requestAnimationFrame`, never React state per frame. Rebuild walls on resize.
- Embla loop needs enough slides to fill the track; duplicate short lists.
- Motion is the `motion` package, imported from `motion/react` (not `framer-motion`). Check the installed version.
- The live clock causes hydration mismatches: render the time only after mount.
