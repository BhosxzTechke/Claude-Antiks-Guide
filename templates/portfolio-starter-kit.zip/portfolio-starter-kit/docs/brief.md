# Project brief — Dan Antiquina Portfolio v2

## Name and one-liner
- Name: Dan Antiquina — Portfolio v2
- Tagline: I build websites that load fast, rank well, and actually convert.

## The problem and the core idea
The current portfolio (portfolio-dan-antiks.vercel.app) is busy and shows projects as a plain table, so clients can't see results. v2 is a calm, editorial, single-page portfolio that sells Dan's web development and SEO services. Inspiration: xhulia.com, for structure and mood only.

## MVP: success looks like
1. The home page matches `docs/design/home.png` on desktop and works at 375px.
2. All four featured projects use real screenshots and real metrics.
3. Physics pills, sticky stacking and the draggable marquee run smoothly and switch off with reduced motion.
4. Lighthouse mobile ≥ 90 for Performance, Accessibility, Best Practices and SEO.
5. Live on Vercel with the custom domain.

## Featured projects
| Project | Headline | Metrics / tech |
|---|---|---|
| Freelance — Web & Digital (2026) | Helping brands like Fronted & Insentra get faster, higher-ranking websites | SEO growth · Core Web Vitals passed · CRO improvements · WordPress & Webflow |
| Pharmacy E-commerce & POS (Capstone) | A full-stack pharmacy store and point-of-sale system in one | Laravel · Inventory tracking · POS checkout · Deployed on Railway |
| Next.js E-commerce (2025) | A modern storefront built for speed and type-safety | Next.js · React · TypeScript · Fast checkout |
| Budget Tracker — Mobile App (2025) | Making personal budgeting feel effortless on mobile | React Native · Expo · Simple expense logging |

Playground only: OJT — Company Website & App, Custom WordPress Portal.

## Services
| Title | Line |
|---|---|
| WordPress & Webflow | Fast, editable sites your team can update |
| Full-Stack Web Apps | Custom systems built with Laravel and Next.js |
| SEO & Speed | Technical SEO and Core Web Vitals that rank |
| Maintenance | Updates, fixes and monitoring every month |

## Toolbox
- Frontend: JavaScript, TypeScript, React, Next.js, Tailwind CSS
- Backend: Laravel, Node.js, Supabase, MySQL
- CMS & SEO: WordPress, Webflow, Search Console, Ahrefs, Screaming Frog
- Tools: Figma, Git, Vercel

## Hero pills
Web Development, SEO, WordPress, Webflow, Laravel, Mobile Apps, Next.js, React, UI/UX

## Screens / pages
- Home — `docs/design/home.png` (approved, final)
- `/work/[slug]` — no design yet
- `/playground` — no design yet

## Open questions
- New repo, or rebuild inside the current portfolio repo?
- Custom domain name?
- Permission to show Fronted and Insentra work?

## Linked docs
- Build plan with diagrams: https://claude.ai/code/artifact/863f1133-008e-47c9-a8e8-b73e1bbfc63e
- Inspiration (mood only): https://www.xhulia.com/
