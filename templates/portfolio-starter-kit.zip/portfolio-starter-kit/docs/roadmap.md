# Roadmap

Each item is one `/plan` → one PR. Prompt files use the roadmap number (`prompts/05-…`); tasks not on the roadmap use `x01`, `x02`, …. `/plan` with no argument picks the first unchecked item; `/ship` ticks it.
Keep items small: if an item needs more than ~15 files, split it.

## Phase 1 — Setup  (done when: an empty styled page deploys to Vercel)
- [ ] 01 — web: scaffold per docs/SETUP.md (create-next-app first, then web/CLAUDE.md, Node 22.x engines, postinstall typegen, Prettier, agentRules off), install stack, fonts, tokens in globals.css
- [ ] 02 — web: typed data files (projects, services, tools, site) with real content
- [ ] 03 — repo: private GitHub repo, first empty commit on main, CI passing, Vercel project (root `web`) with preview deploys

## Phase 2 — Static page  (done when: every section matches the design at 1440px and works at 375px, no effects)
- [ ] 04 — web: Navbar + Hero (photo, clock, headline, buttons, static pills row)
- [ ] 05 — web: Selected Work cards + metric chips + "See all projects" link
- [ ] 06 — web: Services + Toolbox
- [ ] 07 — web: dark Footer + oversized wordmark
- [ ] 08 — web: responsive pass at 375 / 768 / 1440

**Gate:** do not start Phase 3 until Phase 2 is approved by the user on a preview deploy.

## Phase 3 — Effects  (done when: effects work and switch off with reduced motion)
- [ ] 09 — web: draggable physics pills (Matter.js)
- [ ] 10 — web: sticky stacking sections and cards
- [ ] 11 — web: draggable marquee in project panels (Embla)

## Phase 4 — Polish  (done when: motion feels finished and all pages exist)
- [ ] 12 — web: Lenis smooth scroll + fade-up reveals + hover states
- [ ] 13 — web: magnetic CTA buttons
- [ ] 14 — web: /work/[slug] case study pages (design first)
- [ ] 15 — web: /playground page (design first)

## Phase 5 — Launch  (done when: live on the custom domain, Lighthouse mobile ≥ 90)
- [ ] 16 — web: metadata, Open Graph image, sitemap, robots
- [ ] 17 — web: performance and accessibility pass
- [ ] 18 — repo: custom domain on Vercel
