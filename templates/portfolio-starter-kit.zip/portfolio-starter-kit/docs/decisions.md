# Decisions

One line per decision, newest first. Format: `YYYY-MM-DD — decision — why`.
Claude: treat these as settled. Do not reopen them unless the user asks. To add or change one, ask the user first.

2026-10-09 — Node 22.x everywhere (local, CI, `engines`), `@types/node` ^22 — one runtime, no drift between machines and Vercel
2026-10-09 — Repo is private until named client work is cleared — docs name clients without confirmed permission
2026-10-09 — Prompts use roadmap numbers; off-roadmap tasks use x01, x02 — avoids two files with the same number
2026-10-09 — Line endings LF via .gitattributes — Windows CRLF vs Prettier LF made every file look changed
2026-10-09 — Home sections: Navbar, Hero, Selected Work, Services, Toolbox, Footer — clients need services and proof, not activity graphs
2026-10-09 — No GitHub, About stats or Skills sections — skills already show in hero pills, Services and Toolbox
2026-10-09 — Feature 4 projects on home; the rest in /playground — six full cards made the scroll too long
2026-10-09 — Content in TypeScript data files, no CMS or database — one person edits it; static is fastest
2026-10-09 — Contact via mailto link, no form backend in the MVP — no secrets, nothing to maintain
2026-10-09 — Sticky sections: Hero, Selected Work cards, Toolbox — stacking effect without overusing it
2026-10-09 — Matter.js for pills, Embla for the marquee, Motion + Lenis for scroll; no GSAP — one tool per job, all free
2026-10-09 — Instrument Serif + Inter Tight, teal #1FB6C9 accent on #FAFAF7 — matches the approved design
2026-10-09 — Inspiration is xhulia.com for mood only; all copy and details are our own — avoid copying another designer
