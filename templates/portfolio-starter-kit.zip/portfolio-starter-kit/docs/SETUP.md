# Setup checklist

Do these in order, once per project. Most are covered by roadmap items 01 and 03; the rest are yours.

## Before Claude starts (you)

- [ ] Write `AGENTS.md` in the repo root.
- [ ] Export the approved MVP documentation as Markdown to `docs/mvp.md`.
- [ ] Confirm `docs/design/home.png` is the final design.
- [ ] Node **22.x** installed locally (`node -v`). Same major as CI and `engines`.
- [ ] Chrome with the Claude in Chrome extension connected (visual checks don't work in Edge).
- [ ] Optional: copy `.claude/settings.local.example.json` to `.claude/settings.local.json` so screenshot checks stop asking for permission each time.
- [ ] Decide repo visibility: **private** until every client named in the docs (Fronted, Insentra) has cleared their work. Vercel works with private repos.

## Roadmap item 01 — scaffold (Claude, in this order)

1. Run `create-next-app` **before** `web/` exists, or in a temp folder and copy in without overwriting (`create-next-app` refuses non-empty folders).
2. Copy `.claude/templates/web-CLAUDE.md` to `web/CLAUDE.md`.
3. In `web/package.json`: `"engines": { "node": "22.x" }`, `"postinstall": "next typegen"`.
4. `npm install -D @types/node@^22 prettier`.
5. In `next.config.ts`: `agentRules: false`. Review every other generated option and record what you keep in `docs/decisions.md`.
6. `npm ci`, then `npx tsc --noEmit`, `npm run lint`, `npm run build`, `npm audit --omit=dev` (expect 0).

## Roadmap item 03 — repo, CI, Vercel

1. Create the GitHub repo with the visibility decided above (`gh repo create <name> --private`).
2. First push: `/ship` detects the empty remote and offers one empty `chore: initial commit` on `main`. That's the only commit ever made on `main`.
3. Open the PR and watch CI: `gh pr checks <n> --watch`.
4. Import the repo on Vercel with root directory `web`. Vercel reads the Node version from `engines`.

## If something looks wrong

See "Known dependency noise" and "Windows" in `web/CLAUDE.md` before changing anything.
